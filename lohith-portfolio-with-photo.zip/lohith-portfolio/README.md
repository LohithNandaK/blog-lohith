# Lohith Nanda Kesavarapu — Portfolio & Blog

Personal portfolio built with React, TanStack Start, TypeScript, Vite, and Tailwind CSS.

## Run locally

Use Node.js 22.12 or newer and npm.

```sh
npm ci
npm run dev
```

## Production

```sh
npm run build
npm start
```

The production server uses the Node.js Nitro preset. Deploy the generated `.output` folder to a Node.js host. This is a server-rendered app, not a directory of static HTML files.

## Edit content

- `src/content/profile.ts`: introduction, education, skills, certifications, and contact information.
- `src/content/projects.ts`: project entries.
- `src/content/posts.ts`: blog posts.
- `src/styles.css`: theme and styling.
- `public/favicon.svg`: personal LN browser icon.

## Verify

```sh
npm test
npm run build
```
