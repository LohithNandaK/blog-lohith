import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Layout } from "@/components/site";
import { formatDate, getPost, readingTime } from "@/content/posts";

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const post = getPost(params.slug);
    if (!post) throw notFound();
    return { post };
  },
  head: ({ loaderData }) => {
    const t = loaderData ? `${loaderData.post.title} — Lohith Nanda Kesavarapu` : "Article not found";
    const d = loaderData?.post.excerpt ?? "This article could not be found.";
    return {
      meta: [
        { title: t }, { name: "description", content: d },
        { property: "og:title", content: t }, { property: "og:description", content: d },
        { property: "og:type", content: "article" }, { name: "twitter:card", content: "summary_large_image" },
        ...(loaderData ? [] : [{ name: "robots", content: "noindex" }]),
      ],
    };
  },
  notFoundComponent: () => (
    <Layout>
      <div className="mx-auto max-w-3xl px-5 py-24 text-center">
        <h1 className="text-3xl">Article not found</h1>
        <Link to="/blog" className="mt-4 inline-block font-semibold text-teal">Back to the blog</Link>
      </div>
    </Layout>
  ),
  component: PostPage,
});

function PostPage() {
  const { post } = Route.useLoaderData();
  const blocks = post.body.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);
  return (
    <Layout>
      <article className="mx-auto max-w-2xl px-5 py-16">
        <Link to="/blog" className="inline-flex items-center gap-2 text-sm font-semibold text-teal"><ArrowLeft size={16} /> All posts</Link>
        <p className="eyebrow mt-8">{post.category}</p>
        <h1 className="mt-3 text-4xl md:text-5xl">{post.title}</h1>
        <p className="mt-4 text-sm text-muted-foreground">{formatDate(post.date)} · {readingTime(post.body)} min read</p>
        {post.cover && <img src={post.cover} alt="" className="mt-8 w-full rounded-2xl border border-border" />}
        <div className="rule-line my-10" />
        <div className="prose-article text-lg">
          {blocks.map((b, i) => (b.startsWith("## ") ? <h2 key={i}>{b.slice(3)}</h2> : <p key={i}>{b}</p>))}
        </div>
      </article>
    </Layout>
  );
}
