import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Layout, SectionHeading } from "@/components/site";
import { formatDate, readingTime, sortedPosts } from "@/content/posts";

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: "Blog — Lohith Nanda Kesavarapu" },
      { name: "description", content: "Writing on AI learning, programming, projects, and workshops by Lohith Nanda Kesavarapu." },
      { property: "og:title", content: "Blog — Lohith Nanda Kesavarapu" },
      { property: "og:description", content: "Writing on AI learning, programming, projects, and workshops." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BlogPage,
});

function BlogPage() {
  const all = sortedPosts();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const cats = ["All", ...Array.from(new Set(all.map((p) => p.category)))];
  const list = useMemo(
    () => all.filter((p) => (cat === "All" || p.category === cat) && (p.title + p.excerpt + p.body).toLowerCase().includes(q.toLowerCase())),
    [all, q, cat],
  );
  return (
    <Layout>
      <section className="mx-auto max-w-3xl px-5 py-20">
        <SectionHeading eyebrow="Blog" title="Notes & articles" />
        {all.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card p-10 text-center">
            <p className="font-display text-2xl">Writing coming soon</p>
            <p className="mx-auto mt-2 max-w-md text-muted-foreground">Posts about projects, AI learning, programming, and workshops will appear here.</p>
          </div>
        ) : (
          <>
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <label className="relative flex-1">
                <span className="sr-only">Search posts</span>
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden />
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search posts" className="w-full rounded-full border border-input bg-card py-2.5 pl-9 pr-4" />
              </label>
              <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
                {cats.map((c) => (
                  <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c} className={`rounded-full border px-3 py-1.5 text-sm ${cat === c ? "border-primary bg-primary text-primary-foreground" : "border-border"}`}>{c}</button>
                ))}
              </div>
            </div>
            <ul className="mt-8 divide-y divide-border">
              {list.map((p) => (
                <li key={p.slug} className="py-6">
                  <Link to="/blog/$slug" params={{ slug: p.slug }} className="group block">
                    <p className="text-sm text-muted-foreground">{formatDate(p.date)} · {p.category} · {readingTime(p.body)} min read</p>
                    <h2 className="mt-1 text-2xl group-hover:text-teal">{p.title}</h2>
                    <p className="mt-2 text-muted-foreground">{p.excerpt}</p>
                  </Link>
                </li>
              ))}
              {list.length === 0 && <li className="py-6 text-muted-foreground">No posts match your search.</li>}
            </ul>
          </>
        )}
      </section>
    </Layout>
  );
}
