import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Award, ChevronDown, Code2, Database, Globe, Linkedin, Mail, MapPin, Palette, Sparkles, Download } from "lucide-react";
import { Layout, Monogram, SectionHeading } from "@/components/site";
import { certifications, earlierEducation, education, languages, profile, skillGroups, workshops } from "@/content/profile";
import { projects } from "@/content/projects";
import { formatDate, readingTime, sortedPosts } from "@/content/posts";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Lohith Nanda Kesavarapu — B.Tech Student · AI & ML" },
      { name: "description", content: "Portfolio and blog of Lohith Nanda Kesavarapu, a B.Tech AI student at Aditya University exploring machine learning and generative AI." },
      { property: "og:title", content: "Lohith Nanda Kesavarapu — AI & ML Enthusiast" },
      { property: "og:description", content: "Projects, learning notes, and writing from a B.Tech AI student at Aditya University." },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const skillIcons = [Code2, Globe, Database, Sparkles, Palette];

function Home() {
  const posts = sortedPosts().slice(0, 3);
  return (
    <Layout>
      {/* Introduction */}
      <section className="bg-hero">
        <div className="mx-auto grid max-w-5xl items-center gap-12 px-5 py-20 md:grid-cols-[1.4fr_1fr] md:py-28">
          <div>
            <p className="eyebrow">{profile.headline}</p>
            <h1 className="mt-4 text-5xl font-medium md:text-6xl">
              Lohith Nanda <em className="font-normal text-teal">Kesavarapu</em>
            </h1>
            <p className="mt-4 flex items-center gap-2 text-muted-foreground">
              <MapPin size={16} aria-hidden /> {profile.location}
            </p>
            <p className="mt-6 max-w-xl text-lg">{profile.intro}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              {projects.length ? (
                <Link to="/projects" className="btn-primary">Explore my work <ArrowRight size={16} /></Link>
              ) : (
                <a href="#about" className="btn-primary">About me <ArrowRight size={16} /></a>
              )}
              <a href="#contact" className="btn-outline">Get in touch</a>
            </div>
          </div>
          <div className="flex justify-center md:justify-end"><Monogram /></div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="mx-auto max-w-5xl px-5 py-20">
        <SectionHeading eyebrow="About" title="A student building practical skills" />
        <div className="grid gap-10 md:grid-cols-[1.5fr_1fr]">
          <div className="space-y-4 text-lg">{profile.about.map((p) => <p key={p}>{p}</p>)}</div>
          <aside className="rounded-2xl border border-border bg-card p-6">
            <h3 className="text-lg">Languages</h3>
            <ul className="mt-4 space-y-3">
              {languages.map((l) => (
                <li key={l.name} className="flex justify-between gap-4 border-b border-border pb-3 last:border-0 last:pb-0">
                  <span className="font-semibold">{l.name}</span>
                  <span className="text-right text-sm text-muted-foreground">{l.level}</span>
                </li>
              ))}
            </ul>
          </aside>
        </div>
      </section>

      {/* Skills */}
      <section id="skills" className="border-y border-border bg-secondary/60">
        <div className="mx-auto max-w-5xl px-5 py-20">
          <SectionHeading eyebrow="Technical skills" title="What I’m learning and using" />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {skillGroups.map((g, i) => {
              const Icon = skillIcons[i % skillIcons.length] ?? Code2;
              return (
                <div key={g.label} className="rounded-2xl border border-border bg-card p-6 shadow-card">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-teal-soft text-teal"><Icon size={20} aria-hidden /></span>
                  <h3 className="mt-4 text-lg">{g.label}</h3>
                  <ul className="mt-3 flex flex-wrap gap-2">
                    {g.items.map((s) => <li key={s} className="rounded-full border border-border px-3 py-1 text-sm">{s}</li>)}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Projects */}
      {projects.length > 0 && (
        <section id="projects" className="mx-auto max-w-5xl px-5 py-20">
          <SectionHeading eyebrow="Featured projects" title="Things I’ve built" />
          <div className="grid gap-6 md:grid-cols-2">
            {projects.slice(0, 4).map((p) => (
              <Link key={p.slug} to="/projects/$slug" params={{ slug: p.slug }} className="group rounded-2xl border border-border bg-card p-6 shadow-card transition-colors hover:border-teal">
                <h3 className="text-xl group-hover:text-teal">{p.title}</h3>
                <p className="mt-2 text-muted-foreground">{p.description}</p>
                <ul className="mt-4 flex flex-wrap gap-2 text-xs">{p.technologies.map((t) => <li key={t} className="rounded-full bg-teal-soft px-2.5 py-1 text-accent-foreground">{t}</li>)}</ul>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Education */}
      <section id="education" className="mx-auto max-w-5xl px-5 py-20">
        <SectionHeading eyebrow="Education" title="Where I’ve studied" />
        <ol className="relative ml-2 border-l border-border">
          {education.map((e) => (
            <li key={e.school + e.period} className="mb-10 ml-8">
              <span className={`absolute -left-[7px] mt-2 h-3.5 w-3.5 rounded-full border-2 border-background ${e.highlight ? "bg-teal" : "bg-muted-foreground"}`} aria-hidden />
              <p className="text-sm font-semibold text-teal">{e.period}</p>
              <h3 className={e.highlight ? "mt-1 text-2xl" : "mt-1 text-xl"}>{e.school}</h3>
              <p className="text-muted-foreground">{e.detail}</p>
            </li>
          ))}
        </ol>
        <details className="group ml-2 rounded-xl border border-border bg-card px-5 py-4">
          <summary className="flex cursor-pointer list-none items-center justify-between font-semibold">
            Earlier education <ChevronDown size={18} className="transition-transform group-open:rotate-180" aria-hidden />
          </summary>
          <ul className="mt-4 space-y-3">
            {earlierEducation.map((e) => (
              <li key={e.school} className="flex flex-col justify-between gap-1 text-sm sm:flex-row">
                <span><span className="font-semibold">{e.school}</span> · {e.detail}</span>
                <span className="text-muted-foreground">{e.period}</span>
              </li>
            ))}
          </ul>
        </details>
      </section>

      {/* Certifications */}
      <section id="certifications" className="border-y border-border bg-secondary/60">
        <div className="mx-auto max-w-5xl px-5 py-20">
          <SectionHeading eyebrow="Certifications & workshops" title="Learning milestones" />
          <ul className="grid gap-4 md:grid-cols-3">
            {certifications.map((c) => (
              <li key={c.title} className="flex gap-4 rounded-2xl border border-border bg-card p-5">
                <Award className="mt-1 shrink-0 text-teal" size={22} aria-hidden />
                <div>
                  <h3 className="text-base font-semibold leading-snug">{c.title}</h3>
                  {(c.issuer || c.date) && <p className="mt-1 text-sm text-muted-foreground">{[c.issuer, c.date].filter(Boolean).join(" · ")}</p>}
                  {c.credentialUrl && <a href={c.credentialUrl} target="_blank" rel="noreferrer" className="mt-2 inline-block text-sm text-teal underline">View credential</a>}
                </div>
              </li>
            ))}
          </ul>
          {workshops.length > 0 && (
            <div className="mt-12 space-y-6">
              <h3 className="text-2xl">Workshops</h3>
              {workshops.map((w) => (
                <article key={w.title} className="rounded-2xl border border-border bg-card p-6">
                  <h4 className="text-xl">{w.title}</h4>
                  <p className="text-sm text-muted-foreground">{w.organizer} · {w.date}</p>
                  <p className="mt-3">{w.learned}</p>
                  {w.photos && w.photos.length > 0 && (
                    <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-3">{w.photos.map((src) => <img key={src} src={src} alt={`${w.title} photo`} className="rounded-lg object-cover" />)}</div>
                  )}
                  {w.linkedinPost && <a href={w.linkedinPost} target="_blank" rel="noreferrer" className="mt-3 inline-block text-sm text-teal underline">Read the LinkedIn post</a>}
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Writing */}
      <section id="writing" className="mx-auto max-w-5xl px-5 py-20">
        <SectionHeading eyebrow="Recent writing" title="Notes & articles" />
        {posts.length ? (
          <ul className="divide-y divide-border">
            {posts.map((p) => (
              <li key={p.slug} className="py-5">
                <Link to="/blog/$slug" params={{ slug: p.slug }} className="group block">
                  <p className="text-sm text-muted-foreground">{formatDate(p.date)} · {p.category} · {readingTime(p.body)} min read</p>
                  <h3 className="mt-1 text-xl group-hover:text-teal">{p.title}</h3>
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <div className="rounded-2xl border border-dashed border-border bg-card p-10 text-center">
            <p className="font-display text-2xl">Writing coming soon</p>
            <p className="mx-auto mt-2 max-w-md text-muted-foreground">I’ll be sharing notes on AI learning, programming, and projects here.</p>
          </div>
        )}
        <Link to="/blog" className="mt-6 inline-flex items-center gap-2 font-semibold text-teal">Visit the blog <ArrowRight size={16} /></Link>
      </section>

      {/* Contact */}
      <section id="contact" className="bg-primary text-primary-foreground">
        <div className="mx-auto max-w-5xl px-5 py-20 text-center">
          <p className="eyebrow">Contact</p>
          <h2 className="mt-3 text-4xl">Let’s connect</h2>
          <p className="mx-auto mt-4 max-w-lg opacity-80">Open to conversations with professors, recruiters, and fellow learners.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a href={`mailto:${profile.email}`} className="inline-flex items-center gap-2 rounded-full bg-primary-foreground px-5 py-3 font-semibold text-primary transition-opacity hover:opacity-90"><Mail size={18} aria-hidden /> {profile.email}</a>
            <a href={profile.linkedin} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/40 px-5 py-3 font-semibold transition-colors hover:bg-primary-foreground/10"><Linkedin size={18} aria-hidden /> LinkedIn</a>
            {profile.resume && <a href={profile.resume} download className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/40 px-5 py-3 font-semibold hover:bg-primary-foreground/10"><Download size={18} aria-hidden /> Résumé</a>}
          </div>
        </div>
      </section>
    </Layout>
  );
}
