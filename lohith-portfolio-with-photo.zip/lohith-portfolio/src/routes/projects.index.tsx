import { createFileRoute, Link } from "@tanstack/react-router";
import { Layout, SectionHeading } from "@/components/site";
import { projects } from "@/content/projects";

export const Route = createFileRoute("/projects/")({
  head: () => ({
    meta: [
      { title: "Projects — Lohith Nanda Kesavarapu" },
      { name: "description", content: "Projects by Lohith Nanda Kesavarapu, a B.Tech AI student." },
      { property: "og:title", content: "Projects — Lohith Nanda Kesavarapu" },
      { property: "og:description", content: "Projects by Lohith Nanda Kesavarapu, a B.Tech AI student." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  return (
    <Layout>
      <section className="mx-auto max-w-5xl px-5 py-20">
        <SectionHeading eyebrow="Projects" title="Things I’ve built" />
        {projects.length ? (
          <div className="grid gap-6 md:grid-cols-2">
            {projects.map((p) => (
              <Link key={p.slug} to="/projects/$slug" params={{ slug: p.slug }} className="group rounded-2xl border border-border bg-card p-6 shadow-card hover:border-teal">
                <h2 className="text-xl group-hover:text-teal">{p.title}</h2>
                <p className="mt-2 text-muted-foreground">{p.description}</p>
              </Link>
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-border bg-card p-10 text-center">
            <p className="font-display text-2xl">Projects coming soon</p>
            <Link to="/" className="mt-4 inline-block font-semibold text-teal">Back home</Link>
          </div>
        )}
      </section>
    </Layout>
  );
}
