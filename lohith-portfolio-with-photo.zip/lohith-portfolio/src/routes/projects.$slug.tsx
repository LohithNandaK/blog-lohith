import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ExternalLink, Github } from "lucide-react";
import { Layout } from "@/components/site";
import { getProject } from "@/content/projects";

export const Route = createFileRoute("/projects/$slug")({
  loader: ({ params }) => {
    const project = getProject(params.slug);
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => {
    const t = loaderData ? `${loaderData.project.title} — Lohith Nanda Kesavarapu` : "Project not found";
    const d = loaderData?.project.description ?? "This project could not be found.";
    return {
      meta: [
        { title: t }, { name: "description", content: d },
        { property: "og:title", content: t }, { property: "og:description", content: d },
        { property: "og:type", content: "article" }, { name: "twitter:card", content: "summary_large_image" },
        ...(loaderData ? [] : [{ name: "robots", content: "noindex" }]),
      ],
    };
  },
  notFoundComponent: () => (
    <Layout>
      <div className="mx-auto max-w-3xl px-5 py-24 text-center">
        <h1 className="text-3xl">Project not found</h1>
        <Link to="/" className="mt-4 inline-block font-semibold text-teal">Back home</Link>
      </div>
    </Layout>
  ),
  component: ProjectPage,
});

function Block({ title, text }: { title: string; text?: string | undefined }) {
  if (!text) return null;
  return (<section className="mt-10"><h2 className="text-2xl">{title}</h2><p className="mt-3">{text}</p></section>);
}

function ProjectPage() {
  const { project: p } = Route.useLoaderData();
  return (
    <Layout>
      <article className="mx-auto max-w-3xl px-5 py-16">
        <Link to="/projects" className="inline-flex items-center gap-2 text-sm font-semibold text-teal"><ArrowLeft size={16} /> All projects</Link>
        <h1 className="mt-6 text-4xl md:text-5xl">{p.title}</h1>
        <p className="mt-4 text-lg text-muted-foreground">{p.description}</p>
        <ul className="mt-5 flex flex-wrap gap-2 text-sm">{p.technologies.map((t) => <li key={t} className="rounded-full bg-teal-soft px-3 py-1 text-accent-foreground">{t}</li>)}</ul>
        {(p.github || p.demo) && (
          <div className="mt-6 flex flex-wrap gap-3">
            {p.github && <a href={p.github} target="_blank" rel="noreferrer" className="btn-outline"><Github size={16} /> Repository</a>}
            {p.demo && <a href={p.demo} target="_blank" rel="noreferrer" className="btn-primary"><ExternalLink size={16} /> Live demo</a>}
          </div>
        )}
        <div className="rule-line my-10" />
        <Block title="Problem" text={p.problem} />
        <Block title="My contribution" text={p.contribution} />
        {p.screenshots && p.screenshots.length > 0 && (
          <section className="mt-10 grid gap-4">{p.screenshots.map((s) => <img key={s.src} src={s.src} alt={s.alt} className="rounded-xl border border-border" />)}</section>
        )}
        <Block title="Outcome & learning" text={p.outcome} />
      </article>
    </Layout>
  );
}
