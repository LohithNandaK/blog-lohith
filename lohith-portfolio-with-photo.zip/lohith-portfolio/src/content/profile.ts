// Personal details. Leave optional fields empty ("") to hide them on the site.
export const profile = {
  name: "Lohith Nanda Kesavarapu",
  firstName: "Lohith",
  headline: "B.Tech Student · AI & ML Enthusiast",
  location: "Kakinada, Andhra Pradesh, India",
  intro:
    "I’m Lohith, a B.Tech student at Aditya University exploring artificial intelligence, programming, and generative AI tools. This is where I share my projects, learning experiences, and ideas.",
  about: [
    "I’m at the start of my engineering journey, studying Artificial Intelligence at Aditya University. I’m building practical skills step by step — writing programs in Python and C, learning how the web and databases work, and experimenting with generative AI tools.",
    "I enjoy turning what I learn into small, useful things, and I’m using this space to document that process openly as I grow.",
  ],
  email: "lohithnandak@outlook.com",
  linkedin: "https://www.linkedin.com/in/lohith-nanda-kesavarapu-a4696b41a",
  // Add when available:
  github: "",
  photo: "/lohith-profile.jpeg",
  resume: "", // résumé PDF URL; the download button shows once set
};

export const skillGroups = [
  { label: "Programming", items: ["Python", "C"] },
  { label: "Web fundamentals", items: ["HTML", "CSS"] },
  { label: "Databases", items: ["SQL"] },
  { label: "AI tools", items: ["Generative AI tools"] },
  { label: "Creative & presentation", items: ["Canva", "Open Broadcaster Software (OBS)"] },
];

export const languages = [
  { name: "Telugu", level: "Native or bilingual" },
  { name: "English", level: "Professional working proficiency" },
  { name: "Hindi", level: "Limited working proficiency" },
];

export const education = [
  {
    school: "Aditya University",
    detail: "Bachelor of Technology, Artificial Intelligence",
    period: "July 2026 – 2030 (expected)",
    highlight: true,
  },
  { school: "Aditya Talent School", detail: "Classes 9–12, CBSE", period: "June 2022 – May 2026" },
];

export const earlierEducation = [
  { school: "Aditya Talent School", detail: "Classes 6–8", period: "2019 – 2022" },
  { school: "Aditya Public School JKPur", detail: "Classes 2–5", period: "2015 – 2019" },
  { school: "Saranya Concept School G.Vemavaram", detail: "Kindergarten – Class 1, CBSE", period: "2012 – 2015" },
];

export type Certification = {
  title: string;
  issuer?: string;
  date?: string;
  credentialUrl?: string;
  image?: string;
};

export const certifications: Certification[] = [
  { title: "Introduction to Generative AI - Art of the Possible" },
  { title: "Foundations in Generative AI" },
  { title: "AI Tools Workshop" },
];

export type Workshop = {
  title: string;
  organizer: string;
  date: string;
  learned: string;
  photos?: string[];
  linkedinPost?: string;
};

// Add workshop entries here; the section appears once one exists.
export const workshops: Workshop[] = [];
