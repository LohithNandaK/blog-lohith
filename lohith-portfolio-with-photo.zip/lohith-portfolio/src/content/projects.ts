export type Project = {
  slug: string;
  title: string;
  description: string;
  problem?: string;
  contribution?: string;
  technologies: string[];
  screenshots?: { src: string; alt: string }[];
  outcome?: string;
  github?: string;
  demo?: string;
};

// Add projects here. The Projects section and nav link appear once this list has entries.
export const projects: Project[] = [];

export const getProject = (slug: string) => projects.find((p) => p.slug === slug);
