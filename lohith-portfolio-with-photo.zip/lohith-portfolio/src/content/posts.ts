export type Post = {
  slug: string;
  title: string;
  date: string; // YYYY-MM-DD
  category: string;
  excerpt: string;
  cover?: string;
  body: string; // paragraphs separated by blank lines; lines starting with "## " become headings
};

// Add articles here. Until then, the blog shows "Writing coming soon".
export const posts: Post[] = [];

export const sortedPosts = () => [...posts].sort((a, b) => b.date.localeCompare(a.date));
export const getPost = (slug: string) => posts.find((p) => p.slug === slug);

export function readingTime(text: string): number {
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.ceil(words / 220));
}

export const formatDate = (d: string) =>
  new Date(d + "T00:00:00").toLocaleDateString("en-IN", { year: "numeric", month: "long", day: "numeric" });
