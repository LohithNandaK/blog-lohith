import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { Menu, X } from "lucide-react";
import { profile } from "@/content/profile";
import { projects } from "@/content/projects";

export function Monogram({ size = "lg" }: { size?: "sm" | "lg" }) {
  if (profile.photo && size === "lg")
    return <img src={profile.photo} alt={profile.name} width={208} height={208} className="h-40 w-40 rounded-full object-cover object-center shadow-card ring-1 ring-border ring-offset-4 ring-offset-background md:h-52 md:w-52" />;
  const cls = size === "sm" ? "h-9 w-9 text-sm" : "h-40 w-40 text-5xl md:h-52 md:w-52 md:text-6xl";
  return (
    <span
      aria-hidden={size === "sm"}
      className={`bg-monogram inline-flex items-center justify-center rounded-full font-display font-semibold tracking-tight text-primary-foreground shadow-card ring-1 ring-border ring-offset-4 ring-offset-background ${cls}`}
    >
      LN
    </span>
  );
}

function navItems() {
  const items: { label: string; to: string; hash?: string }[] = [
    { label: "About", to: "/", hash: "about" },
  ];
  if (projects.length) items.push({ label: "Projects", to: "/projects" });
  items.push({ label: "Blog", to: "/blog" }, { label: "Education", to: "/", hash: "education" }, { label: "Contact", to: "/", hash: "contact" });
  return items;
}

export function Header() {
  const [open, setOpen] = useState(false);
  const items = navItems();
  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3">
        <Link to="/" className="flex items-center gap-3 font-display text-lg font-semibold">
          <Monogram size="sm" />
          <span className="hidden sm:inline">Lohith Nanda</span>
        </Link>
        <nav aria-label="Main" className="hidden md:block">
          <ul className="flex gap-7 text-[0.95rem] font-medium">
            {items.map((i) => (
              <li key={i.label}>
                <Link to={i.to} {...(i.hash ? { hash: i.hash } : {})} className="text-muted-foreground transition-colors hover:text-teal" {...(i.hash ? {} : { activeProps: { className: "text-teal" } })}>
                  {i.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <button
          className="rounded-md p-2 md:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          aria-controls="mobile-nav"
          onClick={() => setOpen(!open)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-border md:hidden">
          <ul className="mx-auto flex max-w-5xl flex-col px-5 py-3">
            {items.map((i) => (
              <li key={i.label}>
                <Link to={i.to} {...(i.hash ? { hash: i.hash } : {})} onClick={() => setOpen(false)} className="block py-2.5 font-medium">
                  {i.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-5xl flex-col gap-2 px-5 py-8 text-sm text-muted-foreground sm:flex-row sm:justify-between">
        <p>© {new Date().getFullYear()} {profile.name}</p>
        <p>{profile.location}</p>
      </div>
    </footer>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-card focus:px-3 focus:py-2">
        Skip to content
      </a>
      <Header />
      <main id="main" className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

export function SectionHeading({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="mb-10">
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="mt-2 text-3xl md:text-4xl">{title}</h2>
      <div className="rule-line mt-5 w-40" />
    </div>
  );
}
